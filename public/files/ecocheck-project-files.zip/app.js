let model = null;

// Grab necessary HTML elements
const imageInput = document.getElementById("imageInput");
const preview = document.getElementById("preview");
const analyzeBtn = document.getElementById("analyzeBtn");
const resultDiv = document.getElementById("result");

let selectedFile = null;


// TASK 1 — Load the AI model (MobileNet)
// ===================================================
async function loadModel() {

}

// Image Preview — runs automatically when user uploads a file
// ===================================================
imageInput.onchange = () => {
};



// TASK 2 — Run the AI model on the image
// ===================================================
analyzeBtn.onclick = async () => {

};



// TASK 3 — Add recycling keywords
// ===================================================
const recyclableWords = [
];

const nonRecyclableWords = [
];



// TASK 4 — Write the recycling decision function
// ===================================================
function getAdvice(label) {

}



// TASK 5 — Display the final result on the page
// ===================================================
function showResult(p) {

}